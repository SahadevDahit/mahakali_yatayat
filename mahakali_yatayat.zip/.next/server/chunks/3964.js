"use strict";
exports.id = 3964;
exports.ids = [3964];
exports.modules = {

/***/ 3964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);






const Company_acc = ({ id  })=>{
    const [formdata, setformdata] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        id: id,
        _id: "",
        Date: "",
        bankName: "",
        income: "",
        depositAmount: "",
        transactionWork: "",
        withdrawAmount: "",
        totalAmount: "",
        remainingAmount: ""
    });
    const fetching = async ()=>{
        await fetch(`${"https://backend.mahakaliyatayat.com"}/company_acc_form/${id}`).then((res)=>{
            return res.json();
        }).then((value)=>{
            setformdata({
                ...formdata,
                _id: value[0]._id,
                Date: value[0].Date,
                bankName: value[0].bankName,
                income: value[0].income,
                depositAmount: value[0].depositAmount,
                transactionWork: value[0].transactionWork,
                withdrawAmount: value[0].withdrawAmount,
                totalAmount: value[0].totalAmount,
                remainingAmount: value[0].remainingAmount
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (id !== "000") {
            fetching();
        }
    }, []);
    const add = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .ZP.post(`${"https://backend.mahakaliyatayat.com"}/company_acc_form/create`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const update = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].put */ .ZP.put(`${"https://backend.mahakaliyatayat.com"}/company_acc_form/update`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const handledelete = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"]["delete"] */ .ZP["delete"](`${"https://backend.mahakaliyatayat.com"}/company_acc_form/delete/${id}`).then((response)=>{
            alert("Sucess in delete");
        }).catch((err)=>console.log(err));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-center",
                children: "Company Account form"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.Date,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        Date: e.target.value
                                    });
                                },
                                placeholder: "Enter Date"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Bank Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.bankName,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        bankName: e.target.value
                                    });
                                },
                                placeholder: "Enter bank Name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Income"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.income,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        income: e.target.value
                                    });
                                },
                                placeholder: "Enter income"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Deposit Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.depositAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        depositAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter deposit Amount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Transaction Work"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.transactionWork,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        transactionWork: e.target.value
                                    });
                                },
                                placeholder: "Enter transactionWork"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Withdraw Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.withdrawAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        withdrawAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter withdrawAmount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Total Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.totalAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        totalAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter total amount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Remaining Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.remainingAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        remainingAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter remainingAmount"
                            })
                        ]
                    }),
                    id == "000" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                        variant: "primary",
                        onClick: (e)=>add(e),
                        children: "Add"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                variant: "primary",
                                onClick: (e)=>update(e),
                                children: "Update"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                variant: "primary",
                                onClick: (e)=>handledelete(e),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Company_acc);


/***/ })

};
;