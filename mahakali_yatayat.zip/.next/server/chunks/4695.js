"use strict";
exports.id = 4695;
exports.ids = [4695];
exports.modules = {

/***/ 4695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);






const Upakar_counter = ({ id  })=>{
    const [formdata, setformdata] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        id: "",
        _id: "",
        date: "",
        particulars: "",
        cbf: "",
        debitAmount: "",
        creditAmount: "",
        DrCr: "",
        balanceAmount: "",
        a_kha: "",
        orphan: ""
    });
    const fetching = async ()=>{
        await fetch(`${"https://backend.mahakaliyatayat.com"}/upakar_counter/${id}`).then((res)=>{
            return res.json();
        }).then((value)=>{
            setformdata({
                ...formdata,
                id: value[0].id,
                _id: value[0]._id,
                date: value[0].date,
                particulars: value[0].particulars,
                cbf: value[0].cbf,
                debitAmount: value[0].debitAmount,
                creditAmount: value[0].creditAmount,
                DrCr: value[0].DrCr,
                balanceAmount: value[0].balanceAmount,
                a_kha: value[0].a_kha,
                orphan: value[0].orphan
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (id !== "000") {
            fetching();
        }
    }, []);
    const add = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .ZP.post(`${"https://backend.mahakaliyatayat.com"}/upakar_counter/create`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const update = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].put */ .ZP.put(`${"https://backend.mahakaliyatayat.com"}/upakar_counter/update`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const handledelete = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"]["delete"] */ .ZP["delete"](`${"https://backend.mahakaliyatayat.com"}/upakar_counter/delete/${id}`).then((response)=>{
            alert("Sucess in delete");
        }).catch((err)=>console.log(err));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-center",
                children: "Upakar Counter"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.date,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        date: e.target.value
                                    });
                                },
                                placeholder: "Enter Date"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Particulars"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.particulars,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        particulars: e.target.value
                                    });
                                },
                                placeholder: "Enter particulars"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "C.B.F"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.cbf,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        cbf: e.target.value
                                    });
                                },
                                placeholder: "Enter cbf"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Debit Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.debitAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        debitAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter debitAmount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Dr/Cr"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.DrCr,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        DrCr: e.target.value
                                    });
                                },
                                placeholder: "Enter DrCr"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Credit Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.creditAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        creditAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter creditAmount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Balance Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.balanceAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        balanceAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter balance Amount "
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "A_Kha"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.a_kha,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        a_kha: e.target.value
                                    });
                                },
                                placeholder: "Enter a_kha"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Label), {
                                children: "Orphan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_3___default().Control), {
                                type: "text",
                                value: formdata.orphan,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        orphan: e.target.value
                                    });
                                },
                                placeholder: "Enter orphan "
                            })
                        ]
                    }),
                    id == "000" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                        variant: "primary",
                        onClick: (e)=>add(e),
                        children: "Add"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                variant: "primary",
                                onClick: (e)=>update(e),
                                children: "Update"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                variant: "primary",
                                onClick: (e)=>handledelete(e),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Upakar_counter);


/***/ })

};
;