"use strict";
exports.id = 3117;
exports.ids = [3117];
exports.modules = {

/***/ 3117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);





const Staffs_salary = ({ id  })=>{
    const [formdata, setformdata] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        id: id,
        _id: "",
        Name: "",
        post: "",
        contact: "",
        joinDate: "",
        total_salary: "",
        withdraw_salary: "",
        remaining_salary: "",
        date: ""
    });
    const fetching = async ()=>{
        await fetch(`${"https://backend.mahakaliyatayat.com"}/staff_salary/${id}`).then((res)=>{
            return res.json();
        }).then((value)=>{
            setformdata({
                ...formdata,
                _id: value[0]._id,
                Name: value[0].Name,
                post: value[0].post,
                contact: value[0].contact,
                joinDate: value[0].joinDate,
                total_salary: value[0].total_salary,
                withdraw_salary: value[0].withdraw_salary,
                remaining_salary: value[0].remaining_salary,
                date: value[0].date
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (id !== "000") {
            fetching();
        }
    }, []);
    const add = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .ZP.post(`${"https://backend.mahakaliyatayat.com"}/staff_salary/create`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const update = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].put */ .ZP.put(`${"https://backend.mahakaliyatayat.com"}/staff_salary/update`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const handledelete = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"]["delete"] */ .ZP["delete"](`${"https://backend.mahakaliyatayat.com"}/staff_salary/delete/${id}`).then((response)=>{
            alert("Sucess in delete");
        }).catch((err)=>console.log(err));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-center",
                children: "Staffs_salary form"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.Name,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        Name: e.target.value
                                    });
                                },
                                placeholder: "Enter Name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Post"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.post,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        post: e.target.value
                                    });
                                },
                                placeholder: "Enter post"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Contact"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.contact,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        contact: e.target.value
                                    });
                                },
                                placeholder: "Enter contact"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Join Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.joinDate,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        joinDate: e.target.value
                                    });
                                },
                                placeholder: "Enter join date"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Total Salary"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.total_salary,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        total_salary: e.target.value
                                    });
                                },
                                placeholder: "Enter total_salary"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Withdraw Salary"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.withdraw_salary,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        withdraw_salary: e.target.value
                                    });
                                },
                                placeholder: "Enter withdraw_salary"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Remaining Salary"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.remaining_salary,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        remaining_salary: e.target.value
                                    });
                                },
                                placeholder: "Enter remaining_salary"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.date,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        date: e.target.value
                                    });
                                },
                                placeholder: "Enter date"
                            })
                        ]
                    }),
                    id == "000" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                        variant: "primary",
                        onClick: (e)=>add(e),
                        children: "Add"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>update(e),
                                children: "Update"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>handledelete(e),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Staffs_salary);


/***/ })

};
;