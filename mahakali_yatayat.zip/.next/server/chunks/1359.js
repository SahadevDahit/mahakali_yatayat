"use strict";
exports.id = 1359;
exports.ids = [1359];
exports.modules = {

/***/ 1359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);





function loans({ id  }) {
    const [formdata, setformdata] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        id: id,
        _id: "",
        date: "",
        shareHolderName: "",
        busno: "",
        loanAmount: "",
        interestAmount: "",
        payAmount: "",
        remainingAmount: ""
    });
    const fetching = async ()=>{
        await fetch(`${"https://backend.mahakaliyatayat.com"}/loan/${id}`).then((res)=>{
            return res.json();
        }).then((value)=>{
            setformdata({
                ...formdata,
                _id: value[0]._id,
                date: value[0].date,
                shareHolderName: value[0].shareHolderName,
                busno: value[0].busno,
                loanAmount: value[0].loanAmount,
                interestAmount: value[0].interestAmount,
                payAmount: value[0].payAmount,
                remainingAmount: value[0].remainingAmount
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (id !== "000") {
            fetching();
        }
    }, []);
    const add = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .ZP.post(`${"https://backend.mahakaliyatayat.com"}/loan/create`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const update = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].put */ .ZP.put(`${"https://backend.mahakaliyatayat.com"}/loan/update`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const handledelete = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"]["delete"] */ .ZP["delete"](`${"https://backend.mahakaliyatayat.com"}/loan/delete/${id}`).then((response)=>{
            alert("Sucess in delete");
        }).catch((err)=>console.log(err));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-center",
                children: "Loan form"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.date,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        date: e.target.value
                                    });
                                },
                                placeholder: "Enter Date"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "ShareHolder Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.shareHolderName,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        shareHolderName: e.target.value
                                    });
                                },
                                placeholder: "Enter shareholder Name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Bus NO"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.busno,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        busno: e.target.value
                                    });
                                },
                                placeholder: "Enter bus no"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Loan Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.loanAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        loanAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter loanAmount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Interest Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.interestAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        interestAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter interestAmount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Pay Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.payAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        payAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter Pay Amount"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Remaining Amount"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.remainingAmount,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        remainingAmount: e.target.value
                                    });
                                },
                                placeholder: "Enter remaining amount"
                            })
                        ]
                    }),
                    id == "000" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                        variant: "primary",
                        onClick: (e)=>add(e),
                        children: "Add"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>update(e),
                                children: "Update"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>handledelete(e),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loans);


/***/ })

};
;