"use strict";
exports.id = 1756;
exports.ids = [1756];
exports.modules = {

/***/ 1756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1937);
/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5226);
/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);





function Shareholder_form({ id  }) {
    const [formdata, setformdata] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        id: id,
        _id: "",
        shareholderName: "",
        busNo: "",
        travelRoute: "",
        registrationDate: "",
        contactNumber: ""
    });
    const fetching = async ()=>{
        await fetch(`${"https://backend.mahakaliyatayat.com"}/shareholder/${id}`).then((res)=>{
            return res.json();
        }).then((value)=>{
            setformdata({
                ...formdata,
                _id: value[0]._id,
                shareholderName: value[0].shareHolderName,
                busNo: value[0].busno,
                travelRoute: value[0].travelRoute,
                registrationDate: value[0].registrationDate,
                busType: value[0].busType,
                contactNumber: value[0].contactNumber
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (id !== "000") {
            fetching();
        }
    }, []);
    const add = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .ZP.post(`${"https://backend.mahakaliyatayat.com"}/shareholder/create`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const update = async (e)=>{
        e.preventDefault();
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].put */ .ZP.put(`${"https://backend.mahakaliyatayat.com"}/shareholder/update`, {
            formdata: formdata
        }).then((response)=>{
            alert("Sucess in created");
        }).catch((err)=>console.log(err));
    };
    const handledelete = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"]["delete"] */ .ZP["delete"](`${"https://backend.mahakaliyatayat.com"}/shareholder/delete/${id}`).then((response)=>{
            alert("Sucess in delete");
        }).catch((err)=>console.log(err));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container pt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: "text-center",
                children: "ShareHolder form"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicEmail",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "ShareHolder Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.shareholderName,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        shareholderName: e.target.value
                                    });
                                },
                                placeholder: "Enter shareholder Name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Bus NO"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.busNo,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        busNo: e.target.value
                                    });
                                },
                                placeholder: "Enter bus no"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Travel Route"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.travelRoute,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        travelRoute: e.target.value
                                    });
                                },
                                placeholder: "Enter bus Travel Route"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Bus Type"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.busType,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        busType: e.target.value
                                    });
                                },
                                placeholder: "Enter bus bus Type"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Registration Date"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.registrationDate,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        registrationDate: e.target.value
                                    });
                                },
                                placeholder: "Enter bus registration date"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Group), {
                        className: "mb-3",
                        controlId: "formBasicPassword",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Label), {
                                children: "Contact Number"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_2___default().Control), {
                                type: "text",
                                value: formdata.contactNumber,
                                onChange: (e)=>{
                                    e.preventDefault();
                                    setformdata({
                                        ...formdata,
                                        contactNumber: e.target.value
                                    });
                                },
                                placeholder: "Enter contact number"
                            })
                        ]
                    }),
                    id == "000" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                        variant: "primary",
                        onClick: (e)=>add(e),
                        children: "Add"
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>update(e),
                                children: "Update"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                variant: "primary",
                                onClick: (e)=>handledelete(e),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Shareholder_form);


/***/ })

};
;